#!/bin/bash

# Change to the project root directory and run the agent
cd ../.. && python -m agents.hello_world.main "$@"
