"""
Custom tools for the CrewAI Multi-Model Demo
"""

from .custom_tool import CustomTool

__all__ = ['CustomTool']