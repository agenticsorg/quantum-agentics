"""
CrewAI Multi-Model Demo using OpenRouter
"""

__version__ = "0.1.0"